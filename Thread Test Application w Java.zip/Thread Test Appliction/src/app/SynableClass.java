package app;

import javax.swing.JButton;

public class SynableClass{

	/**
	 *  Attributes used in SynableClass
	 */
	private boolean _resume;
	private int _numberOfProcesses;
	private int _numberOfComplatedProcesses; 
	private JButton _startButton;

	/**
	 * Constructor method
	 * 
	 * @param numberOfProcesses -- gets total number of process in that moment
	 * @param startButton  -- moved here to stay until all threads tasks done with their tasks
	 */
	public SynableClass(int numberOfProcesses,JButton startButton ){
		_numberOfComplatedProcesses = 0;
		_numberOfProcesses = numberOfProcesses;
		_resume = true;
		_startButton = startButton;
	}
 
	/**
	 *  Checks whether pause button clicked or not 
	 *  	if yes process wait for a notification from resume button
	 *  	when resume button clicked all threads resume to processing
	 */
	public synchronized void check(){
		if(!_resume){
			try{
				wait();
			}catch(Exception e){
				System.out.println(e);
			}
		}
	}
	
	/**
	 *  Checks whether all the processes done 
	 *  if all the threads completed their tasks start button enables again 
	 *  Enabling start button prevents the creating extra processes
	 *  
	 *  @param _numberOfComplatedProcesses  
	 *  @param _numberOfProcesses
	 */
	public synchronized void processDone(){
		_numberOfComplatedProcesses ++;
		if(_numberOfComplatedProcesses==_numberOfProcesses)
		{
			_startButton.setEnabled(true);
			_numberOfComplatedProcesses=0;
		}
		
	}
	
	/**
	 *  Enable to work threads which are paused by the pause button
	 *  
	 *  notifyAll() awaken all threads which are paused
	 *  @param _resume
	 */
	public synchronized void resume(){	
		_resume = true;
		notifyAll();
	}
	
	
	/**
	 *  Stops all working threads
	 *  @param _resume
	 */
	public synchronized void pause(){	
		_resume = false;
	}
}