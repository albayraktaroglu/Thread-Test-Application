package app;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.JLabel;
import javax.swing.JProgressBar;

public class ProgressBar extends Thread {

	
	/*
	 *  Attributes of the PB class
	 */
	int intervalSleep;
    SynableClass sync;
	JLabel totalThread;
	JLabel grandTotal;
    JProgressBar pb;
   
    
    
    // Lock for the preventing collision or deadlock or something
    static Lock lock = new ReentrantLock();

    
	/**
	 * Constructor method for Progress Bar Class
	 * 
	 * 
	 * @param _pb                   thread's current progress bar
	 * @param _totalThread          thread's percentage number
	 * @param _grandTotal  			sum of all thread's percentages
	 * @param _intervalSleep        thread's predefined sleep interval
	 * @param _sync                 provider or check mechanism of the application
	 */
	public ProgressBar(JProgressBar _pb, JLabel _totalThread, JLabel _grandTotal, int _intervalSleep, SynableClass _sync){
		
		this.sync = _sync;
		this.pb = _pb;
		this.totalThread = _totalThread;
		this.grandTotal = _grandTotal;
		this.intervalSleep = _intervalSleep;
		
	}
	
	
	public void run(){
		
		 for(int i=1 ; i<=this.pb.getMaximum();++i){
			
			 // Checks for if clicked Pause 
			 // If that is the case it all threats wait and resume if resume button clicked
			sync.check();
			
			
			lock.lock();
			
			/*
			 *  Updating the progress bars 
			 */
			pb.setValue(i);
			totalThread.setText(  Integer.toString(i) );
			grandTotal.setText( String.valueOf( Integer.parseInt(grandTotal.getText())+ 1 ) );
			
			
			lock.unlock();
		    
			//Sleep function needs try catch to handle errors caused from sleep
		    try{
		    	Thread.sleep(intervalSleep);
		    }
		    catch (InterruptedException e) {
		 		System.out.println("Could not sleep");
				e.printStackTrace();
			}
		    
		}
		 // Checks whether process done 
		sync.processDone();
		
	 }

}
