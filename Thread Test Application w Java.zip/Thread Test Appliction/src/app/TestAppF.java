package app;


import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JProgressBar;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class TestAppF extends JFrame {

	//Constant numbers used in the application
	final static int LIMIT_OF_PROCESSESBAR = 100;
	final static int NUMBER_OF_PROCESSES = 4;
	final static int MAX_PROCESS_BAR_VALUE=100;
	
	//Panel contains the elements 
	private JPanel contentPane;
	
	//ProgressBar in the application
	static JProgressBar progB1;
	static JProgressBar progB2;
	static JProgressBar progB3;
	static JProgressBar progB4;
	
	//Labels to show results and some of the texts
	static JLabel lbl_progB1;
	static JLabel lbl_progB2;
	static JLabel lbl_progB3;	
	static JLabel lbl_progB4;	
	static JLabel lblGrandTotal;	
	static JLabel lbl_grandT;
	
	static JLabel lblTitle;
	static JLabel lbl1;
	static JLabel lbl2;
	static JLabel lbl3;
	static JLabel lbl4;
	
	//Buttons
	static JButton btnStart;
	static JButton btnPause;
	static JButton btnResume;
	
	//This object provides interprocess communication
	static SynableClass sync;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					//Frame started and set
					TestAppF frame = new TestAppF();
					frame.setVisible(true);
					
					
					sync = new SynableClass(NUMBER_OF_PROCESSES,btnStart);
					
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	/**
	 * Create the frame.
	 */
	public TestAppF() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 622, 430);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
	
		
		//Decleration of components in the frame
		lblTitle = new JLabel("Thread Test Application");
		lbl1 = new JLabel("1:");	
		lbl2 = new JLabel("2:");	
		lbl3 = new JLabel("3:");	
		lbl4 = new JLabel("4:");
	
	    progB1 = new JProgressBar(0,LIMIT_OF_PROCESSESBAR);
		progB2 = new JProgressBar(0,LIMIT_OF_PROCESSESBAR);	
		progB3 = new JProgressBar(0,LIMIT_OF_PROCESSESBAR);	
		progB4 = new JProgressBar(0,LIMIT_OF_PROCESSESBAR);

	    lbl_progB1 = new JLabel("0");
		lbl_progB2 = new JLabel("0");
		lbl_progB3 = new JLabel("0");
		lbl_progB4 = new JLabel("0");
		
		lblGrandTotal = new JLabel("Grand Total :");
		
		lbl_grandT = new JLabel("0");
		
		
		
		
		/*
		 * Declaration of the listeners 
		 *  - start
		 *  - pause 
		 *  - resume
		 */
		
		btnStart = new JButton("Start");
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lbl_grandT.setText("0");
				
				btnStart.setEnabled(false);

				Runnable Th0 = new ProgressBar (progB1,lbl_progB1,lbl_grandT,10,sync);
				Runnable Th1 = new ProgressBar (progB2,lbl_progB2,lbl_grandT,20,sync);
				Runnable Th2 = new ProgressBar (progB3,lbl_progB3,lbl_grandT,30,sync);
				Runnable Th3 = new ProgressBar (progB4,lbl_progB4,lbl_grandT,40,sync);
				new Thread(Th0).start();
				new Thread(Th1).start();
				new Thread(Th2).start();
				new Thread(Th3).start();
				
			}

		});
		
		btnPause = new JButton("Pause");
		btnPause.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sync.pause();
			}
		});
		
		btnResume = new JButton("Resume");
		btnResume.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sync.resume();
			}
		});
		
		
		/*
		 *  Alignment of the frame components - GROUPLAYOUT 
		 */
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(226)
							.addComponent(lblTitle))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(52)
									.addComponent(btnStart)
									.addGap(18)
									.addComponent(btnPause)
									.addGap(18)
									.addComponent(btnResume)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(lblGrandTotal))
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addGap(60)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lbl1)
										.addComponent(lbl2)
										.addComponent(lbl3)
										.addComponent(lbl4))
									.addGap(40)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(progB4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(progB3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(progB2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(progB1, GroupLayout.DEFAULT_SIZE, 372, Short.MAX_VALUE))))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lbl_grandT)
								.addComponent(lbl_progB4)
								.addComponent(lbl_progB3)
								.addComponent(lbl_progB2)
								.addComponent(lbl_progB1))))
					.addContainerGap(50, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblTitle)
					.addGap(65)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lbl1)
						.addComponent(progB1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lbl_progB1))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lbl2)
						.addComponent(progB2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lbl_progB2))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lbl3)
						.addComponent(progB3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lbl_progB3))
					.addGap(30)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lbl4)
								.addComponent(progB4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(61)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnStart)
								.addComponent(btnPause)
								.addComponent(btnResume)
								.addComponent(lblGrandTotal)
								.addComponent(lbl_grandT)))
						.addComponent(lbl_progB4))
					.addContainerGap(62, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
	

}
